package TDAPila;
public class EmptyStackException extends Exception{
	public EmptyStackException(String s) {
		super(s);
	}
}
