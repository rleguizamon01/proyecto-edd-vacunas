package TDALista;
@SuppressWarnings("serial")

public class BoundaryViolationException extends Exception {
	public BoundaryViolationException (String msj) {
		super(msj);
	}
}

