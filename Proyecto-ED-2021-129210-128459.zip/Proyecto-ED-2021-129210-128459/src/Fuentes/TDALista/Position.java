package TDALista;

public interface Position<E>
{

	/**
	 * 
	 * @return Elemento de la posicion
	 */
	public E element();
}