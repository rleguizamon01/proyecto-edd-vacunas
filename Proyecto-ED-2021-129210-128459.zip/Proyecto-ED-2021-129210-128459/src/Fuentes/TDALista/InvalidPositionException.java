package TDALista;

@SuppressWarnings("serial")

public class InvalidPositionException extends Exception {
	public InvalidPositionException (String msj) {
		super(msj);
	}
}

