package TDALista;

@SuppressWarnings("serial")

public class EmptyListException extends Exception {
	public EmptyListException (String msj) {
		super(msj);
	}
}

