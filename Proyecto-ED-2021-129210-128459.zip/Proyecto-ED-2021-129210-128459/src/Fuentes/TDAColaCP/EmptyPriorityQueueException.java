package TDAColaCP;
public class EmptyPriorityQueueException extends Exception {
	public EmptyPriorityQueueException(String s) {
		super(s);
	}
}
